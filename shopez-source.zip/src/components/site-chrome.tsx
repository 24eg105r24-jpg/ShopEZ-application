import { Link, useRouterState } from "@tanstack/react-router";
import { ShoppingCart, User as UserIcon, LogOut, LayoutDashboard, Package } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useCartCount } from "@/lib/cart-hooks";

export function SiteHeader() {
  const { user, isSeller, signOut } = useAuth();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const count = useCartCount();

  const nav = [
    { to: "/", label: "Home" },
    { to: "/products", label: "Shop" },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link to="/" className="font-display text-2xl font-semibold tracking-tight text-primary">
          Shop<span className="text-accent">EZ</span>
        </Link>
        <nav className="hidden gap-6 md:flex">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className={`text-sm transition-colors hover:text-primary ${path === n.to ? "text-primary font-medium" : "text-foreground/70"}`}
            >
              {n.label}
            </Link>
          ))}
          {user && (
            <Link
              to="/orders"
              className={`text-sm transition-colors hover:text-primary ${path === "/orders" ? "text-primary font-medium" : "text-foreground/70"}`}
            >
              Orders
            </Link>
          )}
          {isSeller && (
            <Link
              to="/seller"
              className={`text-sm transition-colors hover:text-primary ${path.startsWith("/seller") ? "text-primary font-medium" : "text-foreground/70"}`}
            >
              Seller
            </Link>
          )}
        </nav>
        <div className="flex items-center gap-2">
          <Link
            to="/cart"
            className="relative inline-flex h-10 w-10 items-center justify-center rounded-full text-foreground/70 hover:bg-secondary hover:text-primary"
            aria-label="Cart"
          >
            <ShoppingCart className="h-5 w-5" />
            {count > 0 && (
              <span className="absolute -right-1 -top-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-[11px] font-semibold text-accent-foreground">
                {count}
              </span>
            )}
          </Link>
          {user ? (
            <button
              onClick={signOut}
              className="inline-flex items-center gap-2 rounded-full px-3 py-2 text-sm text-foreground/70 hover:bg-secondary hover:text-primary"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Sign out</span>
            </button>
          ) : (
            <Link
              to="/auth"
              className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-soft hover:brightness-110"
            >
              <UserIcon className="h-4 w-4" /> Sign in
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border bg-secondary/40">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:grid-cols-2 md:grid-cols-4 sm:px-6">
        <div>
          <div className="font-display text-xl font-semibold text-primary">ShopEZ</div>
          <p className="mt-2 text-sm text-muted-foreground">
            Effortless online shopping — curated products, honest reviews, secure checkout.
          </p>
        </div>
        <div>
          <div className="mb-3 text-sm font-semibold">Shop</div>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/products">All Products</Link></li>
            <li><Link to="/products" search={{ category: "Electronics" }}>Electronics</Link></li>
            <li><Link to="/products" search={{ category: "Home" }}>Home</Link></li>
          </ul>
        </div>
        <div>
          <div className="mb-3 text-sm font-semibold">Account</div>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/auth">Sign in</Link></li>
            <li><Link to="/orders">My orders</Link></li>
            <li><Link to="/cart">Cart</Link></li>
          </ul>
        </div>
        <div>
          <div className="mb-3 text-sm font-semibold">Sellers</div>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2"><LayoutDashboard className="h-4 w-4" /> Dashboard</li>
            <li className="flex items-center gap-2"><Package className="h-4 w-4" /> Order management</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border px-4 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} ShopEZ. Built with love.
      </div>
    </footer>
  );
}
