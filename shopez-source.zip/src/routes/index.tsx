import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ArrowRight, ShieldCheck, Truck, Sparkles, Star } from "lucide-react";
import { priceAfterDiscount } from "@/lib/cart-hooks";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const { data: products = [] } = useQuery({
    queryKey: ["featured-products"],
    queryFn: async () => {
      const { data } = await supabase
        .from("products")
        .select("id, name, price, discount_percent, image_url, category")
        .order("created_at", { ascending: false })
        .limit(6);
      return data ?? [];
    },
  });

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
        <div className="mx-auto grid max-w-7xl gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:py-28">
          <div className="flex flex-col justify-center">
            <span className="mb-4 inline-flex w-fit items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 text-accent" /> New season · Up to 25% off
            </span>
            <h1 className="font-display text-5xl font-semibold leading-[1.05] text-foreground sm:text-6xl lg:text-7xl">
              Shopping,<br />made <em className="text-primary not-italic">effortless.</em>
            </h1>
            <p className="mt-6 max-w-lg text-lg text-muted-foreground">
              ShopEZ curates products worth owning — honest reviews, transparent pricing,
              and a checkout that just works.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/products"
                className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-lift transition hover:brightness-110"
              >
                Shop the catalog <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/auth"
                className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-6 py-3 text-sm font-medium text-foreground hover:bg-secondary"
              >
                Become a seller
              </Link>
            </div>
            <div className="mt-10 flex flex-wrap gap-6 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-primary" /> Secure checkout</span>
              <span className="inline-flex items-center gap-2"><Truck className="h-4 w-4 text-primary" /> Fast delivery</span>
              <span className="inline-flex items-center gap-2"><Star className="h-4 w-4 text-accent" /> Verified reviews</span>
            </div>
          </div>
          <div className="relative">
            <div className="card-surface aspect-[4/5] overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1000"
                alt="Curated products"
                className="h-full w-full object-cover"
              />
            </div>
            <div className="card-surface absolute -bottom-6 -left-6 hidden w-56 p-4 sm:block">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Today's pick</div>
              <div className="mt-1 font-display text-lg font-semibold">Coffee, elevated</div>
              <div className="mt-2 text-sm text-primary">From $51.20</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="font-display text-3xl font-semibold sm:text-4xl">Featured products</h2>
            <p className="mt-2 text-muted-foreground">Hand-picked essentials from our catalog.</p>
          </div>
          <Link to="/products" className="hidden text-sm text-primary hover:underline sm:inline">
            View all →
          </Link>
        </div>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p) => {
            const finalPrice = priceAfterDiscount(Number(p.price), p.discount_percent);
            return (
              <Link
                key={p.id}
                to="/products/$id"
                params={{ id: p.id }}
                className="card-surface group overflow-hidden transition hover:-translate-y-1 hover:shadow-lift"
              >
                <div className="aspect-square overflow-hidden bg-secondary">
                  <img src={p.image_url} alt={p.name} className="h-full w-full object-cover transition group-hover:scale-105" />
                </div>
                <div className="p-5">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">{p.category}</div>
                  <div className="mt-1 font-medium">{p.name}</div>
                  <div className="mt-2 flex items-baseline gap-2">
                    <span className="text-lg font-semibold text-primary">${finalPrice.toFixed(2)}</span>
                    {p.discount_percent > 0 && (
                      <span className="text-sm text-muted-foreground line-through">${Number(p.price).toFixed(2)}</span>
                    )}
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>
    </div>
  );
}
