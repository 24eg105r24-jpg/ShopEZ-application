import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";
import { toast } from "sonner";
import { Star, ShoppingCart, ArrowLeft } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useCartActions, priceAfterDiscount } from "@/lib/cart-hooks";

export const Route = createFileRoute("/products/$id")({
  component: ProductDetail,
});

function ProductDetail() {
  const { id } = Route.useParams();
  const { user } = useAuth();
  const { add } = useCartActions();
  const navigate = useNavigate();
  const [qty, setQty] = useState(1);
  const [comment, setComment] = useState("");
  const [rating, setRating] = useState(5);

  const { data: product } = useQuery({
    queryKey: ["product", id],
    queryFn: async () => {
      const { data } = await supabase.from("products").select("*").eq("id", id).single();
      return data;
    },
  });

  const { data: reviews = [], refetch: refetchReviews } = useQuery({
    queryKey: ["reviews", id],
    queryFn: async () => {
      const { data } = await supabase
        .from("reviews")
        .select("id, rating, comment, created_at, user_id")
        .eq("product_id", id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  if (!product) return <div className="py-24 text-center text-muted-foreground">Loading…</div>;

  const finalPrice = priceAfterDiscount(Number(product.price), product.discount_percent);
  const avgRating = reviews.length
    ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length
    : 0;

  const handleAdd = async () => {
    if (!user) {
      toast.error("Please sign in to add to cart");
      navigate({ to: "/auth" });
      return;
    }
    await add(product.id, qty);
    toast.success(`Added ${qty} × ${product.name} to cart`);
  };

  const submitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.error("Sign in to leave a review");
      return;
    }
    const { error } = await supabase
      .from("reviews")
      .upsert({ product_id: id, user_id: user.id, rating, comment }, { onConflict: "product_id,user_id" });
    if (error) toast.error(error.message);
    else {
      toast.success("Review posted");
      setComment("");
      refetchReviews();
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <Link to="/products" className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary">
        <ArrowLeft className="h-4 w-4" /> Back to shop
      </Link>
      <div className="grid gap-10 lg:grid-cols-2">
        <div className="card-surface overflow-hidden">
          <img src={product.image_url} alt={product.name} className="aspect-square w-full object-cover" />
        </div>
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">{product.category}</div>
          <h1 className="mt-2 font-display text-4xl font-semibold">{product.name}</h1>
          {reviews.length > 0 && (
            <div className="mt-2 flex items-center gap-2 text-sm">
              <div className="flex">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={`h-4 w-4 ${i < Math.round(avgRating) ? "fill-accent text-accent" : "text-muted-foreground/40"}`} />
                ))}
              </div>
              <span className="text-muted-foreground">{avgRating.toFixed(1)} · {reviews.length} reviews</span>
            </div>
          )}
          <div className="mt-6 flex items-baseline gap-3">
            <span className="text-3xl font-semibold text-primary">${finalPrice.toFixed(2)}</span>
            {product.discount_percent > 0 && (
              <>
                <span className="text-lg text-muted-foreground line-through">${Number(product.price).toFixed(2)}</span>
                <span className="rounded-full bg-accent/20 px-2 py-0.5 text-xs font-semibold text-accent-foreground">Save {product.discount_percent}%</span>
              </>
            )}
          </div>
          <p className="mt-6 leading-relaxed text-foreground/80">{product.description}</p>
          <div className="mt-8 flex items-center gap-4">
            <div className="flex items-center rounded-full border border-border">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="px-4 py-2 text-lg">−</button>
              <span className="w-8 text-center">{qty}</span>
              <button onClick={() => setQty(qty + 1)} className="px-4 py-2 text-lg">+</button>
            </div>
            <button
              onClick={handleAdd}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-soft hover:brightness-110"
            >
              <ShoppingCart className="h-4 w-4" /> Add to cart
            </button>
          </div>
          <p className="mt-4 text-xs text-muted-foreground">{product.stock} in stock · Free shipping over $50</p>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-16">
        <h2 className="font-display text-2xl font-semibold">Customer reviews</h2>
        {user && (
          <form onSubmit={submitReview} className="card-surface mt-4 p-6">
            <div className="mb-3 flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Your rating:</span>
              {Array.from({ length: 5 }).map((_, i) => (
                <button type="button" key={i} onClick={() => setRating(i + 1)}>
                  <Star className={`h-5 w-5 ${i < rating ? "fill-accent text-accent" : "text-muted-foreground/40"}`} />
                </button>
              ))}
            </div>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
              placeholder="Share your thoughts…"
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary"
            />
            <button className="mt-3 rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground">Post review</button>
          </form>
        )}
        <div className="mt-6 space-y-4">
          {reviews.length === 0 && <p className="text-muted-foreground">No reviews yet — be the first!</p>}
          {reviews.map((r) => (
            <div key={r.id} className="card-surface p-5">
              <div className="flex items-center gap-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={`h-4 w-4 ${i < r.rating ? "fill-accent text-accent" : "text-muted-foreground/40"}`} />
                ))}
                <span className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleDateString()}</span>
              </div>
              {r.comment && <p className="mt-2 text-sm">{r.comment}</p>}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
