import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Trash2, ArrowRight } from "lucide-react";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { useCart, useCartActions, priceAfterDiscount } from "@/lib/cart-hooks";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [{ title: "Your cart — ShopEZ" }, { name: "description", content: "Review items in your ShopEZ cart." }] }),
  component: CartPage,
});

function CartPage() {
  const { user, loading } = useAuth();
  const nav = useNavigate();
  const { data: items = [], isLoading } = useCart();
  const { update, remove } = useCartActions();

  useEffect(() => {
    if (!loading && !user) nav({ to: "/auth" });
  }, [loading, user, nav]);

  const subtotal = items.reduce(
    (s, r) => s + priceAfterDiscount(Number(r.product.price), r.product.discount_percent) * r.quantity,
    0,
  );
  const shipping = subtotal > 50 || subtotal === 0 ? 0 : 6.99;
  const total = subtotal + shipping;

  if (!user) return null;
  if (isLoading) return <div className="py-24 text-center text-muted-foreground">Loading cart…</div>;

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-4xl font-semibold">Your cart</h1>
      {items.length === 0 ? (
        <div className="card-surface mt-10 p-16 text-center">
          <p className="text-muted-foreground">Your cart is empty.</p>
          <Link to="/products" className="mt-4 inline-flex rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground">
            Start shopping
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
          <div className="space-y-4">
            {items.map((row) => {
              const finalPrice = priceAfterDiscount(Number(row.product.price), row.product.discount_percent);
              return (
                <div key={row.id} className="card-surface flex gap-4 p-4">
                  <img src={row.product.image_url} alt={row.product.name} className="h-24 w-24 rounded-lg object-cover" />
                  <div className="flex-1">
                    <Link to="/products/$id" params={{ id: row.product.id }} className="font-medium hover:text-primary">
                      {row.product.name}
                    </Link>
                    <div className="mt-1 text-sm text-primary">${finalPrice.toFixed(2)}</div>
                    <div className="mt-3 flex items-center gap-3">
                      <div className="flex items-center rounded-full border border-border">
                        <button onClick={() => update(row.id, row.quantity - 1)} className="px-3 py-1">−</button>
                        <span className="w-8 text-center text-sm">{row.quantity}</span>
                        <button onClick={() => update(row.id, row.quantity + 1)} className="px-3 py-1">+</button>
                      </div>
                      <button onClick={() => remove(row.id)} className="text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  <div className="text-right font-semibold">${(finalPrice * row.quantity).toFixed(2)}</div>
                </div>
              );
            })}
          </div>
          <div className="card-surface h-fit p-6">
            <h2 className="font-display text-xl font-semibold">Summary</h2>
            <dl className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between"><dt className="text-muted-foreground">Subtotal</dt><dd>${subtotal.toFixed(2)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Shipping</dt><dd>{shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`}</dd></div>
              <div className="mt-3 flex justify-between border-t border-border pt-3 text-base font-semibold"><dt>Total</dt><dd>${total.toFixed(2)}</dd></div>
            </dl>
            <Link
              to="/checkout"
              className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3 text-sm font-medium text-primary-foreground shadow-lift hover:brightness-110"
            >
              Checkout <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
