import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { CheckCircle2, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { useCart, useCartActions, priceAfterDiscount } from "@/lib/cart-hooks";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [{ title: "Checkout — ShopEZ" }, { name: "description", content: "Complete your ShopEZ order securely." }] }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const { user, loading } = useAuth();
  const nav = useNavigate();
  const { data: items = [] } = useCart();
  const { clear } = useCartActions();
  const [address, setAddress] = useState("");
  const [card, setCard] = useState("4242 4242 4242 4242");
  const [busy, setBusy] = useState(false);
  const [orderId, setOrderId] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && !user) nav({ to: "/auth" });
  }, [loading, user, nav]);

  const subtotal = items.reduce(
    (s, r) => s + priceAfterDiscount(Number(r.product.price), r.product.discount_percent) * r.quantity,
    0,
  );
  const shipping = subtotal > 50 || subtotal === 0 ? 0 : 6.99;
  const total = subtotal + shipping;

  const placeOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || items.length === 0) return;
    setBusy(true);
    try {
      const { data: order, error } = await supabase
        .from("orders")
        .insert({ user_id: user.id, total, shipping_address: address, status: "confirmed" })
        .select()
        .single();
      if (error) throw error;

      const orderItems = items.map((r) => ({
        order_id: order.id,
        product_id: r.product.id,
        seller_id: null,
        quantity: r.quantity,
        unit_price: priceAfterDiscount(Number(r.product.price), r.product.discount_percent),
        product_name: r.product.name,
      }));
      const { error: itemsErr } = await supabase.from("order_items").insert(orderItems);
      if (itemsErr) throw itemsErr;

      await clear();
      setOrderId(order.id);
      toast.success("Order confirmed!");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Checkout failed");
    } finally {
      setBusy(false);
    }
  };

  if (!user) return null;

  if (orderId) {
    return (
      <div className="mx-auto max-w-lg px-4 py-24 text-center">
        <div className="card-surface p-10">
          <CheckCircle2 className="mx-auto h-16 w-16 text-success" />
          <h1 className="mt-4 font-display text-3xl font-semibold">Thank you!</h1>
          <p className="mt-2 text-muted-foreground">Your order is confirmed.</p>
          <p className="mt-1 font-mono text-xs text-muted-foreground">#{orderId.slice(0, 8).toUpperCase()}</p>
          <div className="mt-6 flex justify-center gap-3">
            <button onClick={() => nav({ to: "/orders" })} className="rounded-full bg-primary px-5 py-2 text-sm text-primary-foreground">View orders</button>
            <button onClick={() => nav({ to: "/products" })} className="rounded-full border border-border px-5 py-2 text-sm">Keep shopping</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-4xl font-semibold">Checkout</h1>
      <form onSubmit={placeOrder} className="mt-8 grid gap-8 lg:grid-cols-[1fr_380px]">
        <div className="space-y-6">
          <section className="card-surface p-6">
            <h2 className="font-display text-xl font-semibold">Shipping</h2>
            <label className="mt-4 block text-sm font-medium">Address</label>
            <textarea
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              rows={3}
              placeholder="Street, city, postal code, country"
              className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary"
            />
          </section>
          <section className="card-surface p-6">
            <h2 className="font-display text-xl font-semibold">Payment</h2>
            <p className="mt-1 text-xs text-muted-foreground">Demo checkout — no real charge.</p>
            <label className="mt-4 block text-sm font-medium">Card number</label>
            <div className="mt-1 flex items-center gap-2 rounded-lg border border-input bg-background px-3">
              <Lock className="h-4 w-4 text-muted-foreground" />
              <input
                required
                value={card}
                onChange={(e) => setCard(e.target.value)}
                className="w-full bg-transparent py-2 text-sm outline-none"
              />
            </div>
          </section>
        </div>
        <div className="card-surface h-fit p-6">
          <h2 className="font-display text-xl font-semibold">Order summary</h2>
          <ul className="mt-4 space-y-3 text-sm">
            {items.map((r) => {
              const price = priceAfterDiscount(Number(r.product.price), r.product.discount_percent);
              return (
                <li key={r.id} className="flex justify-between gap-4">
                  <span className="text-foreground/80">{r.product.name} × {r.quantity}</span>
                  <span>${(price * r.quantity).toFixed(2)}</span>
                </li>
              );
            })}
          </ul>
          <dl className="mt-6 space-y-2 border-t border-border pt-4 text-sm">
            <div className="flex justify-between"><dt className="text-muted-foreground">Subtotal</dt><dd>${subtotal.toFixed(2)}</dd></div>
            <div className="flex justify-between"><dt className="text-muted-foreground">Shipping</dt><dd>{shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`}</dd></div>
            <div className="mt-2 flex justify-between border-t border-border pt-2 text-base font-semibold"><dt>Total</dt><dd>${total.toFixed(2)}</dd></div>
          </dl>
          <button
            disabled={busy || items.length === 0}
            className="mt-6 w-full rounded-full bg-primary py-3 text-sm font-medium text-primary-foreground shadow-lift hover:brightness-110 disabled:opacity-60"
          >
            {busy ? "Placing order…" : `Pay $${total.toFixed(2)}`}
          </button>
        </div>
      </form>
    </div>
  );
}
