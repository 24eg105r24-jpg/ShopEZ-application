import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Package, DollarSign, ShoppingBag, Plus } from "lucide-react";

export const Route = createFileRoute("/seller")({
  head: () => ({ meta: [{ title: "Seller dashboard — ShopEZ" }, { name: "description", content: "Manage products, orders, and analytics." }] }),
  component: SellerDashboard,
});

function SellerDashboard() {
  const { user, isSeller, loading, refreshRoles } = useAuth();
  const nav = useNavigate();

  useEffect(() => { if (!loading && !user) nav({ to: "/auth" }); }, [loading, user, nav]);

  const becomeSeller = async () => {
    if (!user) return;
    const { error } = await supabase.from("user_roles").insert({ user_id: user.id, role: "seller" });
    if (error && !error.message.includes("duplicate")) toast.error(error.message);
    else {
      toast.success("You're now a seller!");
      await refreshRoles();
    }
  };

  if (!user) return null;

  if (!isSeller) {
    return (
      <div className="mx-auto max-w-lg px-4 py-24 text-center">
        <div className="card-surface p-10">
          <h1 className="font-display text-3xl font-semibold">Become a seller</h1>
          <p className="mt-2 text-muted-foreground">Start listing products and reach ShopEZ customers.</p>
          <button onClick={becomeSeller} className="mt-6 rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground">
            Enable seller mode
          </button>
        </div>
      </div>
    );
  }

  return <SellerContent userId={user.id} />;
}

function SellerContent({ userId }: { userId: string }) {
  const [showForm, setShowForm] = useState(false);
  const { data: products = [], refetch: refetchProducts } = useQuery({
    queryKey: ["seller-products", userId],
    queryFn: async () => {
      const { data } = await supabase.from("products").select("*").eq("seller_id", userId).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const { data: orderItems = [] } = useQuery({
    queryKey: ["seller-order-items", userId],
    queryFn: async () => {
      const { data } = await supabase.from("order_items").select("*, orders(created_at, status)").eq("seller_id", userId);
      return data ?? [];
    },
  });

  const revenue = orderItems.reduce((s, i) => s + Number(i.unit_price) * i.quantity, 0);
  const orderCount = new Set(orderItems.map((i) => i.order_id)).size;

  // Simple last-7-days chart
  const chartData = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const key = d.toISOString().slice(0, 10);
    const total = orderItems
      .filter((it) => it.orders?.created_at?.slice(0, 10) === key)
      .reduce((s, it) => s + Number(it.unit_price) * it.quantity, 0);
    return { day: d.toLocaleDateString(undefined, { weekday: "short" }), revenue: Math.round(total * 100) / 100 };
  });

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl font-semibold">Seller dashboard</h1>
          <p className="mt-1 text-muted-foreground">Manage products, view orders, track sales.</p>
        </div>
        <button onClick={() => setShowForm((s) => !s)} className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground">
          <Plus className="h-4 w-4" /> {showForm ? "Cancel" : "Add product"}
        </button>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <StatCard icon={<DollarSign className="h-5 w-5" />} label="Revenue" value={`$${revenue.toFixed(2)}`} />
        <StatCard icon={<ShoppingBag className="h-5 w-5" />} label="Orders" value={orderCount.toString()} />
        <StatCard icon={<Package className="h-5 w-5" />} label="Products" value={products.length.toString()} />
      </div>

      <section className="card-surface mt-8 p-6">
        <h2 className="font-display text-xl font-semibold">Revenue — last 7 days</h2>
        <div className="mt-4 h-64">
          <ResponsiveContainer>
            <BarChart data={chartData}>
              <XAxis dataKey="day" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} />
              <Bar dataKey="revenue" fill="var(--color-primary)" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {showForm && <ProductForm userId={userId} onDone={() => { setShowForm(false); refetchProducts(); }} />}

      <section className="mt-8">
        <h2 className="font-display text-xl font-semibold">Your products</h2>
        {products.length === 0 ? (
          <div className="card-surface mt-4 p-8 text-center text-muted-foreground">No products yet — add your first!</div>
        ) : (
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {products.map((p) => (
              <div key={p.id} className="card-surface overflow-hidden">
                <img src={p.image_url} alt={p.name} className="aspect-video w-full object-cover" />
                <div className="p-4">
                  <div className="font-medium">{p.name}</div>
                  <div className="mt-1 text-sm text-primary">${Number(p.price).toFixed(2)}</div>
                  <div className="mt-1 text-xs text-muted-foreground">Stock: {p.stock}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="mt-10">
        <h2 className="font-display text-xl font-semibold">Recent orders</h2>
        {orderItems.length === 0 ? (
          <div className="card-surface mt-4 p-8 text-center text-muted-foreground">No orders yet.</div>
        ) : (
          <div className="card-surface mt-4 overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3">Product</th>
                  <th className="px-4 py-3">Qty</th>
                  <th className="px-4 py-3">Total</th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {orderItems.slice(0, 20).map((it) => (
                  <tr key={it.id}>
                    <td className="px-4 py-3">{it.product_name}</td>
                    <td className="px-4 py-3">{it.quantity}</td>
                    <td className="px-4 py-3">${(Number(it.unit_price) * it.quantity).toFixed(2)}</td>
                    <td className="px-4 py-3"><span className="rounded-full bg-success/15 px-2 py-0.5 text-xs text-success">{it.orders?.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="card-surface flex items-center gap-4 p-5">
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">{icon}</div>
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="mt-1 text-2xl font-semibold">{value}</div>
      </div>
    </div>
  );
}

function ProductForm({ userId, onDone }: { userId: string; onDone: () => void }) {
  const [form, setForm] = useState({
    name: "",
    description: "",
    price: "",
    discount_percent: "0",
    image_url: "",
    category: "Electronics",
    stock: "10",
  });
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.from("products").insert({
      name: form.name,
      description: form.description,
      price: Number(form.price),
      discount_percent: Number(form.discount_percent),
      image_url: form.image_url,
      category: form.category,
      stock: Number(form.stock),
      seller_id: userId,
    });
    setBusy(false);
    if (error) toast.error(error.message);
    else {
      toast.success("Product added");
      onDone();
    }
  };
  return (
    <form onSubmit={submit} className="card-surface mt-6 grid gap-4 p-6 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <label className="mb-1 block text-sm font-medium">Name</label>
        <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" />
      </div>
      <div className="sm:col-span-2">
        <label className="mb-1 block text-sm font-medium">Description</label>
        <textarea required rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium">Price ($)</label>
        <input required type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium">Discount %</label>
        <input type="number" value={form.discount_percent} onChange={(e) => setForm({ ...form, discount_percent: e.target.value })} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium">Category</label>
        <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
          {["Electronics", "Home", "Clothing", "Accessories", "Fitness"].map((c) => <option key={c}>{c}</option>)}
        </select>
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium">Stock</label>
        <input required type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" />
      </div>
      <div className="sm:col-span-2">
        <label className="mb-1 block text-sm font-medium">Image URL</label>
        <input required value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="https://…" className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" />
      </div>
      <div className="sm:col-span-2">
        <button disabled={busy} className="rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground">{busy ? "Saving…" : "Save product"}</button>
      </div>
    </form>
  );
}
