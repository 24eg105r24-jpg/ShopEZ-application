import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";
import { z } from "zod";
import { priceAfterDiscount } from "@/lib/cart-hooks";

const searchSchema = z.object({
  category: z.string().optional(),
  q: z.string().optional(),
});

export const Route = createFileRoute("/products")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({
    meta: [
      { title: "Shop all products — ShopEZ" },
      { name: "description", content: "Browse the ShopEZ catalog — electronics, home, fitness, and more with verified reviews." },
      { property: "og:title", content: "Shop all products — ShopEZ" },
      { property: "og:description", content: "Browse the full ShopEZ catalog." },
    ],
  }),
  component: Products,
});

function Products() {
  const { category, q } = Route.useSearch();
  const [search, setSearch] = useState(q ?? "");
  const navigate = Route.useNavigate();

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["products", category, q],
    queryFn: async () => {
      let query = supabase.from("products").select("*").order("created_at", { ascending: false });
      if (category) query = query.eq("category", category);
      if (q) query = query.ilike("name", `%${q}%`);
      const { data, error } = await query;
      if (error) throw error;
      return data ?? [];
    },
  });

  const categories = ["All", "Electronics", "Home", "Clothing", "Accessories", "Fitness"];

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-4xl font-semibold">Shop</h1>
          <p className="mt-1 text-muted-foreground">{products.length} products{category ? ` in ${category}` : ""}</p>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            navigate({ search: (prev: z.infer<typeof searchSchema>) => ({ ...prev, q: search || undefined }) });
          }}
          className="flex gap-2"
        >
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search products…"
            className="w-full rounded-full border border-input bg-card px-4 py-2 text-sm outline-none focus:border-primary sm:w-72"
          />
          <button className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Search</button>
        </form>
      </div>

      <div className="mb-8 flex flex-wrap gap-2">
        {categories.map((c) => {
          const active = (c === "All" && !category) || category === c;
          return (
            <button
              key={c}
              onClick={() =>
                navigate({ search: (prev: z.infer<typeof searchSchema>) => ({ ...prev, category: c === "All" ? undefined : c }) })
              }
              className={`rounded-full border px-4 py-1.5 text-sm transition ${active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground/70 hover:bg-secondary"}`}
            >
              {c}
            </button>
          );
        })}
      </div>

      {isLoading ? (
        <div className="py-24 text-center text-muted-foreground">Loading products…</div>
      ) : products.length === 0 ? (
        <div className="card-surface py-24 text-center text-muted-foreground">No products match your search.</div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {products.map((p) => {
            const finalPrice = priceAfterDiscount(Number(p.price), p.discount_percent);
            return (
              <Link
                key={p.id}
                to="/products/$id"
                params={{ id: p.id }}
                className="card-surface group overflow-hidden transition hover:-translate-y-1 hover:shadow-lift"
              >
                <div className="relative aspect-square overflow-hidden bg-secondary">
                  <img src={p.image_url} alt={p.name} className="h-full w-full object-cover transition group-hover:scale-105" />
                  {p.discount_percent > 0 && (
                    <span className="absolute left-3 top-3 rounded-full bg-accent px-2 py-0.5 text-xs font-semibold text-accent-foreground">
                      -{p.discount_percent}%
                    </span>
                  )}
                </div>
                <div className="p-4">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">{p.category}</div>
                  <div className="mt-1 font-medium leading-tight">{p.name}</div>
                  <div className="mt-2 flex items-baseline gap-2">
                    <span className="text-base font-semibold text-primary">${finalPrice.toFixed(2)}</span>
                    {p.discount_percent > 0 && (
                      <span className="text-xs text-muted-foreground line-through">${Number(p.price).toFixed(2)}</span>
                    )}
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
