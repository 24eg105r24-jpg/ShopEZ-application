import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Package } from "lucide-react";

export const Route = createFileRoute("/orders")({
  head: () => ({ meta: [{ title: "My orders — ShopEZ" }, { name: "description", content: "Track your ShopEZ orders." }] }),
  component: OrdersPage,
});

function OrdersPage() {
  const { user, loading } = useAuth();
  const nav = useNavigate();

  useEffect(() => { if (!loading && !user) nav({ to: "/auth" }); }, [loading, user, nav]);

  const { data: orders = [] } = useQuery({
    queryKey: ["my-orders", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("orders")
        .select("id, total, status, created_at, shipping_address, order_items(product_name, quantity, unit_price)")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  if (!user) return null;

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-4xl font-semibold">Your orders</h1>
      {orders.length === 0 ? (
        <div className="card-surface mt-8 p-12 text-center text-muted-foreground">
          <Package className="mx-auto mb-3 h-10 w-10" />
          No orders yet.
        </div>
      ) : (
        <div className="mt-8 space-y-4">
          {orders.map((o) => (
            <div key={o.id} className="card-surface p-6">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="font-mono text-xs uppercase text-muted-foreground">#{o.id.slice(0, 8)}</div>
                  <div className="text-sm text-muted-foreground">{new Date(o.created_at).toLocaleString()}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="rounded-full bg-success/15 px-3 py-1 text-xs font-medium text-success">{o.status}</span>
                  <span className="font-semibold">${Number(o.total).toFixed(2)}</span>
                </div>
              </div>
              <ul className="mt-4 space-y-1 text-sm">
                {o.order_items?.map((it, i: number) => (
                  <li key={i} className="flex justify-between text-foreground/80">
                    <span>{it.product_name} × {it.quantity}</span>
                    <span>${(Number(it.unit_price) * it.quantity).toFixed(2)}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-3 text-xs text-muted-foreground">Ship to: {o.shipping_address}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
