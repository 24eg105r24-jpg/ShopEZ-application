import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./auth-context";

export interface CartRow {
  id: string;
  product_id: string;
  quantity: number;
  product: {
    id: string;
    name: string;
    price: number;
    discount_percent: number;
    image_url: string;
    stock: number;
  };
}

export function useCart() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["cart", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<CartRow[]> => {
      const { data, error } = await supabase
        .from("cart_items")
        .select("id, product_id, quantity, product:products(id, name, price, discount_percent, image_url, stock)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as CartRow[];
    },
  });
}

export function useCartCount() {
  const { data } = useCart();
  return (data ?? []).reduce((s, r) => s + r.quantity, 0);
}

export function useCartActions() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["cart", user?.id] });
  return {
    add: async (productId: string, qty = 1) => {
      if (!user) throw new Error("Sign in required");
      const { data: existing } = await supabase
        .from("cart_items")
        .select("id, quantity")
        .eq("user_id", user.id)
        .eq("product_id", productId)
        .maybeSingle();
      if (existing) {
        await supabase.from("cart_items").update({ quantity: existing.quantity + qty }).eq("id", existing.id);
      } else {
        await supabase.from("cart_items").insert({ user_id: user.id, product_id: productId, quantity: qty });
      }
      invalidate();
    },
    update: async (id: string, qty: number) => {
      if (qty <= 0) await supabase.from("cart_items").delete().eq("id", id);
      else await supabase.from("cart_items").update({ quantity: qty }).eq("id", id);
      invalidate();
    },
    remove: async (id: string) => {
      await supabase.from("cart_items").delete().eq("id", id);
      invalidate();
    },
    clear: async () => {
      if (!user) return;
      await supabase.from("cart_items").delete().eq("user_id", user.id);
      invalidate();
    },
  };
}

export function priceAfterDiscount(price: number, discount: number) {
  return Math.round(price * (1 - discount / 100) * 100) / 100;
}
