import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/lib/auth";
import { useCreateOrder } from "@/hooks/use-orders";
import { ApiError } from "@/lib/api";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Cart — ShopEZ" },
      { name: "description", content: "Review your ShopEZ cart and check out." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { items, setQty, remove, subtotal, clear } = useCart();
  const { user } = useAuth();
  const router = useRouter();
  const createOrder = useCreateOrder();
  const [placed, setPlaced] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const shipping = subtotal > 300 || subtotal === 0 ? 0 : 18;
  const total = subtotal + shipping;

  async function handleCheckout() {
    setError(null);
    if (!user) {
      router.navigate({ to: "/login" });
      return;
    }
    try {
      const order = await createOrder.mutateAsync(
        items.map((it) => ({ slug: it.id, quantity: it.quantity })),
      );
      clear();
      setPlaced(order.orderNumber);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Checkout failed. Please try again.");
    }
  }

  if (placed) {
    return (
      <section className="mx-auto max-w-2xl px-6 py-32 text-center">
        <div className="font-mono text-xs uppercase tracking-[0.4em] text-primary">
          Order confirmed
        </div>
        <h1 className="mt-6 font-serif text-6xl italic">Thank you.</h1>
        <p className="mt-6 text-muted-foreground">
          A receipt for order <span className="font-mono text-foreground">{placed}</span> is on its way.
          The maker has been notified and will pack your order within 48 hours.
        </p>
        <Link
          to="/catalog"
          className="mt-10 inline-block bg-foreground px-8 py-4 font-mono text-xs uppercase tracking-widest text-background hover:bg-primary"
        >
          Continue browsing
        </Link>
      </section>
    );
  }

  return (
    <section className="px-6 py-16">
      <div className="mx-auto max-w-7xl">
        <div className="mb-4 font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground">
          Checkout / Cart
        </div>
        <h1 className="mb-12 text-6xl font-extrabold uppercase tracking-tighter md:text-8xl">
          Cart
        </h1>

        {items.length === 0 ? (
          <div className="border border-border p-16 text-center">
            <p className="font-serif text-3xl italic text-muted-foreground">
              Your cart is empty.
            </p>
            <Link
              to="/catalog"
              className="mt-8 inline-block bg-foreground px-8 py-4 font-mono text-xs uppercase tracking-widest text-background hover:bg-primary"
            >
              Browse catalog
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <div className="border-y border-border">
                {items.map((it) => (
                  <div
                    key={it.id}
                    className="grid grid-cols-[80px_minmax(0,1fr)_auto] items-center gap-6 border-b border-border py-6 last:border-b-0 sm:grid-cols-[100px_minmax(0,1fr)_auto_auto]"
                  >
                    <div className="aspect-square overflow-hidden bg-muted ring-1 ring-border">
                      <img src={it.image} alt={it.name} className="h-full w-full object-cover" />
                    </div>
                    <div className="min-w-0">
                      <div className="truncate text-lg font-bold uppercase">{it.name}</div>
                      <div className="font-mono text-xs text-muted-foreground">
                        ${it.price.toFixed(2)} each
                      </div>
                      <button
                        onClick={() => remove(it.id)}
                        className="mt-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground hover:text-primary"
                      >
                        Remove
                      </button>
                    </div>
                    <div className="flex items-center border border-border">
                      <button
                        onClick={() => setQty(it.id, it.quantity - 1)}
                        className="px-3 py-2 font-mono text-sm hover:bg-muted"
                      >
                        −
                      </button>
                      <span className="w-8 text-center font-mono text-sm">{it.quantity}</span>
                      <button
                        onClick={() => setQty(it.id, it.quantity + 1)}
                        className="px-3 py-2 font-mono text-sm hover:bg-muted"
                      >
                        +
                      </button>
                    </div>
                    <div className="col-span-3 text-right font-serif text-xl font-bold italic sm:col-span-1">
                      ${(it.price * it.quantity).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <aside className="lg:col-span-1">
              <div className="sticky top-24 bg-foreground p-8 text-background">
                <h2 className="font-serif text-2xl italic">Order summary</h2>
                <dl className="mt-8 space-y-4 font-mono text-sm">
                  <div className="flex justify-between">
                    <dt className="opacity-60">Subtotal</dt>
                    <dd>${subtotal.toFixed(2)}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="opacity-60">Shipping</dt>
                    <dd>{shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`}</dd>
                  </div>
                  <div className="flex justify-between border-t border-background/20 pt-4 text-lg">
                    <dt>Total</dt>
                    <dd className="font-serif italic text-primary">${total.toFixed(2)}</dd>
                  </div>
                </dl>

                {error && (
                  <p className="mt-4 border border-primary/40 bg-primary/10 px-3 py-2 text-xs text-primary">
                    {error}
                  </p>
                )}

                <button
                  onClick={handleCheckout}
                  disabled={createOrder.isPending}
                  className="mt-8 w-full bg-primary py-4 font-mono text-xs uppercase tracking-widest text-primary-foreground hover:brightness-110 disabled:opacity-50"
                >
                  {createOrder.isPending
                    ? "Placing order…"
                    : user
                      ? "Secure checkout →"
                      : "Sign in to checkout →"}
                </button>
                <p className="mt-4 text-center font-mono text-[10px] uppercase tracking-widest opacity-50">
                  Encrypted · JWT-authenticated checkout
                </p>
              </div>
            </aside>
          </div>
        )}
      </div>
    </section>
  );
}
