import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { api, ApiError } from "@/lib/api";
import { getProductImage } from "@/lib/productImages";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/lib/auth";
import { useProduct, useAddReview } from "@/hooks/use-products";
import type { Product } from "@/lib/types";

export const Route = createFileRoute("/product/$id")({
  loader: async ({ params }): Promise<{ product: Product }> => {
    try {
      const product = await api.get<Product>(`/products/${params.id}`);
      return { product };
    } catch (err) {
      if (err instanceof ApiError && err.status === 404) throw notFound();
      throw err;
    }
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Object not found — ShopEZ" }, { name: "robots", content: "noindex" }] };
    }
    const p = loaderData.product;
    return {
      meta: [
        { title: `${p.name} — ShopEZ` },
        { name: "description", content: p.description },
        { property: "og:title", content: `${p.name} — ShopEZ` },
        { property: "og:description", content: p.tagline },
      ],
    };
  },
  component: ProductPage,
  notFoundComponent: ProductNotFound,
});

function ProductNotFound() {
  return (
    <div className="mx-auto max-w-2xl px-6 py-32 text-center">
      <div className="font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground">Error 404</div>
      <h1 className="mt-6 font-serif text-6xl italic text-primary">out of stock</h1>
      <p className="mt-4 text-muted-foreground">This object is no longer in the catalog.</p>
      <Link
        to="/catalog"
        className="mt-8 inline-block bg-foreground px-6 py-3 font-mono text-xs uppercase tracking-widest text-background hover:bg-primary"
      >
        Back to catalog
      </Link>
    </div>
  );
}

function ProductPage() {
  const { product: initialProduct } = Route.useLoaderData() as { product: Product };
  // Re-fetch client-side so review submissions / stock reflect live without a full page reload.
  const { data } = useProduct(initialProduct.slug);
  const product = data ?? initialProduct;

  const { add } = useCart();
  const { user } = useAuth();
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const price = product.finalPrice;

  return (
    <section className="px-6 py-16">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground">
          <Link to="/catalog" className="hover:text-primary">Catalog</Link> / {product.code}
        </div>

        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
          {/* image */}
          <div className="lg:col-span-7">
            <div className="relative aspect-[4/5] overflow-hidden bg-muted ring-1 ring-border">
              <img
                src={getProductImage(product.imageKey)}
                alt={product.name}
                width={800}
                height={1000}
                className="h-full w-full object-cover"
              />
              {product.discount ? (
                <div className="absolute left-6 top-6 bg-primary px-3 py-1.5 font-mono text-xs text-primary-foreground">
                  -{product.discount}% OFF
                </div>
              ) : null}
            </div>
          </div>

          {/* info */}
          <div className="lg:col-span-5">
            <div className="sticky top-24">
              <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                {product.category} · {product.code}
              </div>
              <h1 className="mt-4 text-5xl font-extrabold uppercase leading-none tracking-tighter">
                {product.name}
              </h1>
              <p className="mt-3 font-serif text-2xl italic text-primary">
                {product.tagline}
              </p>

              <div className="mt-8 flex items-baseline gap-4">
                <span className="font-serif text-4xl font-bold italic">
                  ${price.toFixed(2)}
                </span>
                {product.discount ? (
                  <span className="font-mono text-sm text-muted-foreground line-through">
                    ${product.price.toFixed(2)}
                  </span>
                ) : null}
                <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  ★ {product.avgRating.toFixed(1)} ({product.reviews.length})
                </span>
              </div>

              <p className="mt-8 leading-relaxed text-muted-foreground">
                {product.description}
              </p>

              <div className="mt-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                {product.stock > 0 ? `${product.stock} in stock` : "Out of stock"}
              </div>

              <div className="mt-8 flex items-center gap-4">
                <div className="flex items-center border border-border">
                  <button
                    onClick={() => setQty((q) => Math.max(1, q - 1))}
                    className="px-4 py-3 font-mono text-sm hover:bg-muted"
                  >
                    −
                  </button>
                  <span className="w-10 text-center font-mono text-sm">{qty}</span>
                  <button
                    onClick={() => setQty((q) => Math.min(product.stock || 1, q + 1))}
                    className="px-4 py-3 font-mono text-sm hover:bg-muted"
                  >
                    +
                  </button>
                </div>
                <button
                  disabled={product.stock <= 0}
                  onClick={() => {
                    add({ id: product.slug, name: product.name, price, image: getProductImage(product.imageKey) }, qty);
                    setAdded(true);
                    setTimeout(() => setAdded(false), 1500);
                  }}
                  className="flex-1 bg-foreground py-4 font-mono text-xs uppercase tracking-widest text-background transition-colors hover:bg-primary disabled:opacity-40"
                >
                  {added ? "Added ✓" : product.stock <= 0 ? "Out of stock" : "Add to cart"}
                </button>
              </div>

              {/* specs */}
              <dl className="mt-12 grid grid-cols-2 gap-x-6 gap-y-6 border-t border-border pt-8">
                {product.specs.map((s) => (
                  <div key={s.label}>
                    <dt className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                      {s.label}
                    </dt>
                    <dd className="mt-1 text-sm">{s.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>

        {/* reviews */}
        <div className="mt-24 border-t border-border pt-16">
          <div className="mb-12 flex items-baseline justify-between">
            <h2 className="text-4xl font-extrabold uppercase tracking-tighter">
              Reviews
            </h2>
            <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
              ★ {product.avgRating.toFixed(1)} average · {product.reviews.length} total
            </div>
          </div>

          <ReviewForm slug={product.slug} loggedIn={Boolean(user)} />

          <div className="mt-12 grid grid-cols-1 gap-8 md:grid-cols-2">
            {product.reviews.map((r, i) => (
              <article key={r._id ?? `${r.author}-${i}`} className="border border-border p-8">
                <div className="flex items-baseline justify-between">
                  <span className="font-serif text-xl italic">{r.title}</span>
                  <span className="font-mono text-[10px] uppercase tracking-widest text-primary">
                    {"★".repeat(r.rating)}
                  </span>
                </div>
                <p className="mt-4 text-sm text-muted-foreground">{r.body}</p>
                <div className="mt-6 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                  {r.author} · {r.date}
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function ReviewForm({ slug, loggedIn }: { slug: string; loggedIn: boolean }) {
  const addReview = useAddReview(slug);
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  if (!loggedIn) {
    return (
      <p className="border border-border p-6 text-sm text-muted-foreground">
        <Link to="/login" className="text-foreground underline underline-offset-4 hover:text-primary">
          Sign in
        </Link>{" "}
        to leave a review.
      </p>
    );
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!title.trim() || !body.trim()) return;
        addReview.mutate(
          { rating, title, body },
          { onSuccess: () => { setTitle(""); setBody(""); setRating(5); } },
        );
      }}
      className="border border-border p-6"
    >
      <div className="mb-4 flex items-center gap-4">
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Rating</span>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setRating(n)}
              className={"text-lg " + (n <= rating ? "text-primary" : "text-muted-foreground")}
            >
              ★
            </button>
          ))}
        </div>
      </div>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Review title"
        required
        className="mb-3 w-full border border-border bg-background px-4 py-3 text-sm"
      />
      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        placeholder="Share your thoughts…"
        required
        rows={3}
        className="mb-4 w-full border border-border bg-background px-4 py-3 text-sm"
      />
      <button
        type="submit"
        disabled={addReview.isPending}
        className="bg-foreground px-6 py-3 font-mono text-xs uppercase tracking-widest text-background hover:bg-primary disabled:opacity-50"
      >
        {addReview.isPending ? "Posting…" : "Post review"}
      </button>
    </form>
  );
}
