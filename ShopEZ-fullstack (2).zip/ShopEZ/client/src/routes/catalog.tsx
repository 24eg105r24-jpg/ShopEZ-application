import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { categories, getProductImage } from "@/lib/productImages";
import { useProducts } from "@/hooks/use-products";

export const Route = createFileRoute("/catalog")({
  head: () => ({
    meta: [
      { title: "Catalog — ShopEZ" },
      {
        name: "description",
        content: "Browse the ShopEZ catalog: furniture, ceramics, lighting, textiles, and objects — briefed and shipped by the maker.",
      },
      { property: "og:title", content: "Catalog — ShopEZ" },
      { property: "og:description", content: "Browse the full ShopEZ catalog." },
    ],
  }),
  component: Catalog,
});

type Cat = (typeof categories)[number];
type Sort = "featured" | "low" | "high";

function Catalog() {
  const [cat, setCat] = useState<Cat>("All");
  const [sort, setSort] = useState<Sort>("featured");
  const { data: list, isLoading, isError } = useProducts({ category: cat, sort });

  return (
    <section className="px-6 py-16">
      <div className="mx-auto max-w-7xl">
        <div className="mb-4 font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground">
          Index / Catalog
        </div>
        <div className="mb-12 flex flex-col items-baseline justify-between gap-6 md:flex-row">
          <h1 className="text-6xl font-extrabold uppercase tracking-tighter md:text-8xl">
            Catalog
          </h1>
          <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
            {(list?.length ?? 0).toString().padStart(2, "0")} objects
          </div>
        </div>

        {/* filters */}
        <div className="mb-12 flex flex-col gap-6 border-y border-border py-4 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={
                  "border px-4 py-2 font-mono text-[10px] uppercase tracking-widest transition-colors " +
                  (cat === c
                    ? "border-foreground bg-foreground text-background"
                    : "border-border hover:border-foreground")
                }
              >
                {c}
              </button>
            ))}
          </div>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as Sort)}
            className="border border-border bg-background px-3 py-2 font-mono text-[10px] uppercase tracking-widest"
          >
            <option value="featured">Sort: Featured</option>
            <option value="low">Price: Low → High</option>
            <option value="high">Price: High → Low</option>
          </select>
        </div>

        {isLoading && (
          <div className="border border-border p-16 text-center font-mono text-xs uppercase tracking-widest text-muted-foreground">
            Loading catalog…
          </div>
        )}

        {isError && (
          <div className="border border-primary/40 bg-primary/5 p-16 text-center text-sm text-primary">
            Couldn't reach the ShopEZ API. Make sure the backend server is running.
          </div>
        )}

        {!isLoading && !isError && (
          <div className="grid grid-cols-1 gap-x-8 gap-y-16 md:grid-cols-2 lg:grid-cols-3">
            {list?.map((p) => (
              <Link
                key={p.slug}
                to="/product/$id"
                params={{ id: p.slug }}
                className="group block"
              >
                <div className="relative aspect-[4/5] overflow-hidden bg-muted ring-1 ring-border">
                  <img
                    src={getProductImage(p.imageKey)}
                    alt={p.name}
                    width={800}
                    height={1000}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  {p.discount ? (
                    <div className="absolute left-4 top-4 bg-primary px-2 py-1 font-mono text-[10px] text-primary-foreground">
                      -{p.discount}% OFF
                    </div>
                  ) : null}
                  <div className="absolute right-4 top-4 font-mono text-[10px] uppercase tracking-widest opacity-60">
                    {p.code}
                  </div>
                </div>
                <div className="mt-6 flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <h3 className="truncate text-xl font-bold uppercase tracking-tight">
                      {p.name}
                    </h3>
                    <p className="font-mono text-xs text-muted-foreground">
                      {p.material}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    {p.discount ? (
                      <>
                        <span className="block font-serif text-xl font-bold italic text-primary">
                          ${p.finalPrice.toFixed(0)}
                        </span>
                        <span className="font-mono text-[10px] text-muted-foreground line-through">
                          ${p.price.toFixed(0)}
                        </span>
                      </>
                    ) : (
                      <span className="font-serif text-xl font-bold italic">
                        ${p.price.toFixed(0)}
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
