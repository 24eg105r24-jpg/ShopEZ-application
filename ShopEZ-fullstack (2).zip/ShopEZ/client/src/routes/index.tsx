import { createFileRoute, Link } from "@tanstack/react-router";
import { getProductImage } from "@/lib/productImages";
import { useProducts } from "@/hooks/use-products";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ShopEZ — Curated objects for the considered life" },
      {
        name: "description",
        content:
          "An editorial marketplace for design-forward furniture, lighting, ceramics, and textiles. Every object briefed, sourced, and shipped by ShopEZ.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const { data: products, isLoading } = useProducts();
  const featured = (products ?? []).slice(0, 3);

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden px-6 py-20">
        <div className="mx-auto grid max-w-7xl grid-cols-12 items-end gap-8">
          <div className="animate-in-up col-span-12 lg:col-span-8">
            <div className="mb-6 font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground">
              Collection 01 / Winter 2026
            </div>
            <h1 className="text-[clamp(3.5rem,11vw,9.5rem)] font-extrabold uppercase leading-[0.85] tracking-tighter">
              The New <br />
              <span className="font-serif text-primary font-normal italic lowercase">
                standard
              </span>
            </h1>
          </div>
          <div className="animate-in-up col-span-12 lg:col-span-4 [animation-delay:150ms]">
            <div className="bg-foreground p-8 text-background">
              <p className="mb-6 text-lg leading-snug">
                ShopEZ curates the periphery. Objects of function, rendered in
                form — briefed by us, shipped from the maker.
              </p>
              <Link
                to="/catalog"
                className="block w-full bg-primary py-4 text-center font-mono text-xs uppercase tracking-widest text-primary-foreground transition-all hover:brightness-110"
              >
                Shop Collection 01
              </Link>
            </div>
          </div>
        </div>
        <div className="pointer-events-none absolute -bottom-10 -right-20 select-none font-serif text-[20rem] italic leading-none tracking-tighter text-foreground/[0.04]">
          01
        </div>
      </section>

      {/* MANIFESTO STRIP */}
      <section className="border-y border-border bg-foreground text-background">
        <div className="mx-auto grid max-w-7xl grid-cols-1 divide-y divide-background/10 md:grid-cols-3 md:divide-x md:divide-y-0">
          {[
            { k: "01", t: "Briefed, not sourced", b: "Every object is designed to our spec, not pulled from a catalog." },
            { k: "02", t: "Ships from the maker", b: "No warehouse. The maker packs and sends. You pay for the object, not logistics." },
            { k: "03", t: "Repaired, not replaced", b: "Ten-year repair guarantee on every hard good in the catalog." },
          ].map((c) => (
            <div key={c.k} className="p-10">
              <span className="font-mono text-xs opacity-50">{c.k}</span>
              <h3 className="mt-4 font-serif text-2xl italic">{c.t}</h3>
              <p className="mt-3 text-sm opacity-70">{c.b}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED */}
      <section className="px-6 py-24">
        <div className="mx-auto max-w-7xl">
          <div className="mb-16 flex flex-col items-baseline justify-between gap-4 md:flex-row">
            <h2 className="text-5xl font-extrabold uppercase tracking-tighter">
              Featured
            </h2>
            <Link
              to="/catalog"
              className="font-mono text-xs uppercase tracking-widest hover:text-primary"
            >
              View full catalog →
            </Link>
          </div>
          {isLoading ? (
            <div className="border border-border p-16 text-center font-mono text-xs uppercase tracking-widest text-muted-foreground">
              Loading featured objects…
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-x-8 gap-y-16 md:grid-cols-2 lg:grid-cols-3">
              {featured.map((p, i) => (
                <Link
                  key={p.slug}
                  to="/product/$id"
                  params={{ id: p.slug }}
                  className="group animate-in-up block"
                  style={{ animationDelay: `${200 + i * 100}ms` }}
                >
                  <div className="relative aspect-[4/5] overflow-hidden bg-muted ring-1 ring-border">
                    <img
                      src={getProductImage(p.imageKey)}
                      alt={p.name}
                      width={800}
                      height={1000}
                      loading={i === 0 ? "eager" : "lazy"}
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    {p.discount ? (
                      <div className="absolute left-4 top-4 bg-primary px-2 py-1 font-mono text-[10px] text-primary-foreground">
                        -{p.discount}% OFF
                      </div>
                    ) : null}
                    <div className="absolute right-4 top-4 font-mono text-[10px] uppercase tracking-widest opacity-60">
                      {p.code}
                    </div>
                  </div>
                  <div className="mt-6 flex items-start justify-between">
                    <div>
                      <h3 className="text-xl font-bold uppercase tracking-tight">
                        {p.name}
                      </h3>
                      <p className="font-mono text-xs text-muted-foreground">
                        {p.material}
                      </p>
                    </div>
                    <div className="text-right">
                      {p.discount ? (
                        <>
                          <span className="block font-serif text-xl font-bold italic text-primary">
                            ${p.finalPrice.toFixed(0)}
                          </span>
                          <span className="font-mono text-[10px] text-muted-foreground line-through">
                            ${p.price.toFixed(0)}
                          </span>
                        </>
                      ) : (
                        <span className="font-serif text-xl font-bold italic">
                          ${p.price.toFixed(0)}
                        </span>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* SELLER CTA */}
      <section className="px-6 pb-24">
        <div className="mx-auto max-w-7xl">
          <div className="grid grid-cols-12 items-center gap-8 border border-border bg-muted/40 p-10 md:p-16">
            <div className="col-span-12 md:col-span-7">
              <div className="font-mono text-xs uppercase tracking-[0.4em] text-primary">
                For Makers
              </div>
              <h2 className="mt-4 font-serif text-5xl italic md:text-6xl">
                Sell into a room of buyers who care.
              </h2>
              <p className="mt-6 max-w-lg text-muted-foreground">
                A dashboard built for small studios, not for scale. Real orders,
                real analytics, no dark patterns.
              </p>
            </div>
            <div className="col-span-12 md:col-span-5 md:pl-8">
              <Link
                to="/dashboard"
                className="block w-full bg-foreground py-5 text-center font-mono text-xs uppercase tracking-widest text-background transition-all hover:bg-primary"
              >
                Preview the Seller Portal →
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
