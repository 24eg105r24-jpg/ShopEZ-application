import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { ApiError } from "@/lib/api";
import type { Role } from "@/lib/types";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Create an account — ShopEZ" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: RegisterPage,
});

function RegisterPage() {
  const { register } = useAuth();
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<Role>("buyer");
  const [studioName, setStudioName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const user = await register({ name, email, password, role, studioName });
      router.navigate({ to: user.role === "seller" ? "/dashboard" : "/catalog" });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong. Try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section className="mx-auto max-w-md px-6 py-24">
      <div className="mb-4 font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground">
        Account / Register
      </div>
      <h1 className="mb-10 text-5xl font-extrabold uppercase tracking-tighter">Create an account</h1>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Name
          </label>
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-2 w-full border border-border bg-background px-4 py-3 text-sm"
            placeholder="Jane Doe"
          />
        </div>
        <div>
          <label className="block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Email
          </label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-2 w-full border border-border bg-background px-4 py-3 text-sm"
            placeholder="you@example.com"
          />
        </div>
        <div>
          <label className="block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Password
          </label>
          <input
            type="password"
            required
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-2 w-full border border-border bg-background px-4 py-3 text-sm"
            placeholder="At least 6 characters"
          />
        </div>

        <div>
          <label className="block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Account type
          </label>
          <div className="mt-2 flex gap-2">
            {(["buyer", "seller"] as const).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRole(r)}
                className={
                  "flex-1 border px-4 py-3 font-mono text-[10px] uppercase tracking-widest transition-colors " +
                  (role === r
                    ? "border-foreground bg-foreground text-background"
                    : "border-border hover:border-foreground")
                }
              >
                {r === "buyer" ? "Shopper" : "Seller / maker"}
              </button>
            ))}
          </div>
        </div>

        {role === "seller" && (
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              Studio name
            </label>
            <input
              value={studioName}
              onChange={(e) => setStudioName(e.target.value)}
              className="mt-2 w-full border border-border bg-background px-4 py-3 text-sm"
              placeholder="Studio Monolith"
            />
          </div>
        )}

        {error && (
          <p className="border border-primary/40 bg-primary/5 px-4 py-3 text-sm text-primary">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full bg-foreground py-4 font-mono text-xs uppercase tracking-widest text-background transition-colors hover:bg-primary disabled:opacity-50"
        >
          {submitting ? "Creating account…" : "Create account"}
        </button>
      </form>

      <p className="mt-8 text-center text-sm text-muted-foreground">
        Already have an account?{" "}
        <Link to="/login" className="text-foreground underline underline-offset-4 hover:text-primary">
          Sign in
        </Link>
      </p>
    </section>
  );
}
