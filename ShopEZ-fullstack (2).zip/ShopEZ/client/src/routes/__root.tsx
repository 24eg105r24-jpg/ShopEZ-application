import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { CartProvider } from "../lib/cart";
import { AuthProvider } from "../lib/auth";
import { SiteHeader } from "../components/site-header";
import { SiteFooter } from "../components/site-footer";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">Error 404</div>
        <h1 className="mt-6 font-serif text-6xl italic text-primary">not found</h1>
        <p className="mt-4 text-sm text-muted-foreground">
          The object you're looking for has been moved or is out of stock.
        </p>
        <div className="mt-8">
          <Link
            to="/"
            className="inline-flex items-center justify-center bg-foreground px-6 py-3 font-mono text-xs uppercase tracking-widest text-background transition-all hover:bg-primary"
          >
            Return home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">Runtime error</div>
        <h1 className="mt-6 font-serif text-4xl italic">something broke</h1>
        <p className="mt-4 text-sm text-muted-foreground">
          Try again, or head home while we look into it.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button
            onClick={() => { router.invalidate(); reset(); }}
            className="bg-primary px-6 py-3 font-mono text-xs uppercase tracking-widest text-primary-foreground transition-all hover:brightness-110"
          >
            Try again
          </button>
          <a
            href="/"
            className="border border-foreground px-6 py-3 font-mono text-xs uppercase tracking-widest transition-all hover:bg-foreground hover:text-background"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "ShopEZ — Curated objects for the considered life" },
      {
        name: "description",
        content:
          "An editorial marketplace for design-forward furniture, lighting, ceramics, and textiles. Every object briefed, sourced, and shipped by ShopEZ.",
      },
      { property: "og:title", content: "ShopEZ — Curated objects for the considered life" },
      {
        property: "og:description",
        content: "An editorial marketplace for design-forward furniture, lighting, ceramics, and textiles. Every object briefed, sourced, and shipped by ShopEZ.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "ShopEZ — Curated objects for the considered life" },
      { name: "twitter:description", content: "An editorial marketplace for design-forward furniture, lighting, ceramics, and textiles. Every object briefed, sourced, and shipped by ShopEZ." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/c7c01a44-e59e-4fab-886e-3f411237a951/id-preview-3e436130--e5206b0c-0a43-4c5c-b1e7-3f23d475aa57.lovable.app-1783834737525.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/c7c01a44-e59e-4fab-886e-3f411237a951/id-preview-3e436130--e5206b0c-0a43-4c5c-b1e7-3f23d475aa57.lovable.app-1783834737525.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&family=Playfair+Display:ital,wght@1,700&family=JetBrains+Mono:wght@400;500&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CartProvider>
          <div className="flex min-h-screen flex-col bg-background text-foreground">
            <SiteHeader />
            <main className="flex-1">
              <Outlet />
            </main>
            <SiteFooter />
          </div>
        </CartProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
