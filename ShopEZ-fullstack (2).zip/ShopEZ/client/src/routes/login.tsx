import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { ApiError } from "@/lib/api";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in — ShopEZ" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { login } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const user = await login(email, password);
      router.navigate({ to: user.role === "seller" ? "/dashboard" : "/catalog" });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong. Try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section className="mx-auto max-w-md px-6 py-24">
      <div className="mb-4 font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground">
        Account / Sign in
      </div>
      <h1 className="mb-10 text-5xl font-extrabold uppercase tracking-tighter">Welcome back</h1>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Email
          </label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-2 w-full border border-border bg-background px-4 py-3 text-sm"
            placeholder="you@example.com"
          />
        </div>
        <div>
          <label className="block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Password
          </label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-2 w-full border border-border bg-background px-4 py-3 text-sm"
            placeholder="••••••••"
          />
        </div>

        {error && (
          <p className="border border-primary/40 bg-primary/5 px-4 py-3 text-sm text-primary">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full bg-foreground py-4 font-mono text-xs uppercase tracking-widest text-background transition-colors hover:bg-primary disabled:opacity-50"
        >
          {submitting ? "Signing in…" : "Sign in"}
        </button>
      </form>

      <p className="mt-8 text-center text-sm text-muted-foreground">
        New to ShopEZ?{" "}
        <Link to="/register" className="text-foreground underline underline-offset-4 hover:text-primary">
          Create an account
        </Link>
      </p>

      <div className="mt-10 border-t border-border pt-6 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        Demo accounts · seller@shopez.com / password123 · buyer@shopez.com / password123
      </div>
    </section>
  );
}
