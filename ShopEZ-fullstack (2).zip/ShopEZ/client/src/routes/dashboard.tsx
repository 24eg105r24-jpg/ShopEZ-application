import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useDashboardSummary, useInventory } from "@/hooks/use-dashboard";
import { useAllOrders, useUpdateOrderStatus } from "@/hooks/use-orders";
import type { OrderStatus } from "@/lib/types";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Seller Portal — ShopEZ" },
      {
        name: "description",
        content: "The ShopEZ Seller Portal: manage orders, inventory, and see real analytics — built for small studios.",
      },
      { property: "og:title", content: "Seller Portal — ShopEZ" },
      { property: "og:description", content: "Orders, inventory, and analytics for makers on ShopEZ." },
    ],
  }),
  component: Dashboard,
});

type Tab = "analytics" | "orders" | "inventory";
const STATUSES: OrderStatus[] = ["Processing", "Shipped", "Delivered", "Cancelled"];

function Dashboard() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <section className="bg-foreground px-6 py-32 text-center text-background">
        <p className="font-mono text-xs uppercase tracking-widest opacity-60">Loading…</p>
      </section>
    );
  }

  if (!user || user.role !== "seller") {
    return (
      <section className="bg-foreground px-6 py-32 text-center text-background">
        <div className="font-mono text-xs uppercase tracking-[0.4em] opacity-50">Merchant / Portal</div>
        <h1 className="mt-6 font-serif text-5xl italic">Sellers only</h1>
        <p className="mx-auto mt-4 max-w-md text-sm opacity-70">
          {user
            ? "This account is registered as a shopper. Create a seller account to access the portal."
            : "Sign in with a seller account to manage orders, inventory, and analytics."}
        </p>
        <Link
          to={user ? "/register" : "/login"}
          className="mt-8 inline-block bg-primary px-6 py-3 font-mono text-xs uppercase tracking-widest text-primary-foreground hover:brightness-110"
        >
          {user ? "Create a seller account →" : "Sign in →"}
        </Link>
      </section>
    );
  }

  return <DashboardContent studioName={user.studioName || user.name} />;
}

function DashboardContent({ studioName }: { studioName: string }) {
  const [tab, setTab] = useState<Tab>("analytics");
  const { data: summary, isLoading: summaryLoading } = useDashboardSummary(true);
  const { data: orders, isLoading: ordersLoading } = useAllOrders(tab === "orders");
  const { data: inventory, isLoading: inventoryLoading } = useInventory(tab === "inventory");
  const updateStatus = useUpdateOrderStatus();

  return (
    <section className="bg-foreground px-6 py-16 text-background">
      <div className="mx-auto max-w-7xl">
        <div className="mb-4 font-mono text-xs uppercase tracking-[0.4em] opacity-50">
          Merchant / Portal
        </div>
        <div className="mb-12 flex flex-col items-baseline justify-between gap-6 md:flex-row">
          <h1 className="text-6xl font-extrabold uppercase leading-none tracking-tighter md:text-8xl">
            Seller<br />
            <span className="text-primary">Portal</span>
          </h1>
          <div className="text-right">
            <div className="font-mono text-[10px] uppercase tracking-widest opacity-50">
              {studioName} · Verified
            </div>
            <div className="mt-1 font-serif text-lg italic">Signed in</div>
          </div>
        </div>

        {/* stats */}
        <div className="mb-12 grid grid-cols-2 gap-4 md:grid-cols-4">
          {[
            { label: "Revenue (30d)", value: summaryLoading ? "—" : `$${(summary?.revenue30d ?? 0).toLocaleString()}`, change: `${summary?.totalOrders ?? 0} total orders`, accent: false },
            { label: "Active orders", value: summaryLoading ? "—" : String(summary?.activeOrders ?? 0), change: `${summary?.ordersNeedingAction ?? 0} need action`, accent: true },
            { label: "Repeat customers", value: summaryLoading ? "—" : `${summary?.repeatCustomerRate ?? 0}%`, change: "of buyers", accent: false },
            { label: "Catalog", value: inventory ? String(inventory.length) : "12", change: "objects listed", accent: false },
          ].map((s) => (
            <div
              key={s.label}
              className={"p-6 " + (s.accent ? "bg-primary text-primary-foreground" : "border border-background/20")}
            >
              <span className="block font-mono text-[10px] uppercase tracking-widest opacity-70">
                {s.label}
              </span>
              <span className="mt-3 block text-3xl font-bold">{s.value}</span>
              <span className="mt-2 block font-mono text-[10px] uppercase tracking-widest opacity-70">
                {s.change}
              </span>
            </div>
          ))}
        </div>

        {/* tabs */}
        <div className="mb-8 flex gap-2 border-b border-background/20">
          {(["analytics", "orders", "inventory"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={
                "px-5 py-3 font-mono text-[10px] uppercase tracking-widest transition-colors " +
                (tab === t ? "border-b-2 border-primary text-primary" : "opacity-60 hover:opacity-100")
              }
            >
              {t}
            </button>
          ))}
        </div>

        {tab === "analytics" && (
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            <div className="border border-background/20 p-6 lg:col-span-2">
              <div className="mb-6 flex items-baseline justify-between">
                <span className="font-mono text-[10px] uppercase tracking-widest opacity-60">
                  Sales / 12 months
                </span>
                <span className="font-serif text-2xl italic text-primary">
                  ${(summary?.revenue30d ?? 0).toLocaleString()}
                </span>
              </div>
              <div className="flex h-56 items-end gap-2">
                {(summary?.salesBars ?? Array.from({ length: 12 }, (_, i) => ({ label: "·", total: 0, heightPct: 4 }))).map((h, i, arr) => (
                  <div key={i} className="flex flex-1 flex-col items-center gap-2">
                    <div className="flex w-full flex-1 items-end">
                      <div
                        className={"w-full transition-all " + (i === arr.length - 1 ? "bg-primary" : "bg-background/25")}
                        style={{ height: `${Math.max(4, h.heightPct)}%` }}
                        title={`$${h.total.toFixed(0)}`}
                      />
                    </div>
                    <span className="font-mono text-[10px] opacity-50">{h.label}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="border border-background/20 p-6">
              <span className="block font-mono text-[10px] uppercase tracking-widest opacity-60">
                Top objects
              </span>
              <ul className="mt-6 divide-y divide-background/10">
                {(summary?.topProducts ?? []).length === 0 && (
                  <li className="py-6 text-center font-mono text-[10px] uppercase tracking-widest opacity-50">
                    No sales yet
                  </li>
                )}
                {(summary?.topProducts ?? []).map((r) => (
                  <li key={r.name} className="flex items-baseline justify-between py-3">
                    <div>
                      <div className="text-sm">{r.name}</div>
                      <div className="font-mono text-[10px] opacity-50">{r.units} sold</div>
                    </div>
                    <div className="font-serif italic text-primary">${r.revenue.toLocaleString()}</div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {tab === "orders" && (
          <div className="overflow-x-auto border border-background/20">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="border-b border-background/20 uppercase tracking-widest">
                  <th className="p-4">Order</th>
                  <th className="p-4">Customer</th>
                  <th className="p-4">Items</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Amount</th>
                  <th className="p-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-background/10">
                {ordersLoading && (
                  <tr><td colSpan={6} className="p-8 text-center opacity-60">Loading orders…</td></tr>
                )}
                {!ordersLoading && (orders ?? []).length === 0 && (
                  <tr><td colSpan={6} className="p-8 text-center opacity-60">No orders yet</td></tr>
                )}
                {(orders ?? []).map((o) => (
                  <tr key={o._id} className="hover:bg-background/5">
                    <td className="p-4">#{o.orderNumber}</td>
                    <td className="p-4">{typeof o.user === "object" ? o.user.name : o.user}</td>
                    <td className="p-4 opacity-70">
                      {o.items.map((it) => it.name).join(", ")}
                    </td>
                    <td className="p-4">
                      <span
                        className={
                          "border px-2 py-0.5 text-[10px] " +
                          (o.status === "Processing" ? "border-primary text-primary" : "border-background/30 opacity-70")
                        }
                      >
                        {o.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="p-4 text-right">${o.total.toFixed(2)}</td>
                    <td className="p-4 text-right">
                      <select
                        value={o.status}
                        disabled={updateStatus.isPending}
                        onChange={(e) =>
                          updateStatus.mutate({ id: o._id, status: e.target.value as OrderStatus })
                        }
                        className="border border-background/30 bg-transparent px-2 py-1 text-[10px] uppercase tracking-widest"
                      >
                        {STATUSES.map((s) => (
                          <option key={s} value={s} className="text-foreground">
                            {s}
                          </option>
                        ))}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === "inventory" && (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {inventoryLoading && (
              <div className="col-span-full p-8 text-center font-mono text-xs opacity-60">Loading inventory…</div>
            )}
            {(inventory ?? []).map((i) => (
              <div key={i.slug} className="border border-background/20 p-6">
                <div className="flex items-baseline justify-between">
                  <span className="font-mono text-[10px] uppercase tracking-widest opacity-50">
                    {i.code}
                  </span>
                  {i.low && (
                    <span className="border border-primary px-2 py-0.5 font-mono text-[10px] text-primary">
                      LOW
                    </span>
                  )}
                </div>
                <h3 className="mt-3 text-xl font-bold uppercase">{i.name}</h3>
                <div className="mt-6 flex items-baseline justify-between">
                  <span className="font-serif text-4xl italic">{i.stock}</span>
                  <span className="font-mono text-[10px] uppercase tracking-widest opacity-50">
                    units in stock
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
