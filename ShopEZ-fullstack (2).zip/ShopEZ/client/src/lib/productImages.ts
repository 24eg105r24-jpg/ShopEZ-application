import stool from "@/assets/product-stool.jpg";
import vase from "@/assets/product-vase.jpg";
import lamp from "@/assets/product-lamp.jpg";
import throwImg from "@/assets/product-throw.jpg";
import notebook from "@/assets/product-notebook.jpg";
import bookend from "@/assets/product-bookend.jpg";
import carafe from "@/assets/product-carafe.jpg";
import clock from "@/assets/product-clock.jpg";
import board from "@/assets/product-board.jpg";
import incense from "@/assets/product-incense.jpg";
import slippers from "@/assets/product-slippers.jpg";
import kettle from "@/assets/product-kettle.jpg";

// The backend stores an `imageKey` per product instead of a binary image
// (no upload pipeline needed). This map turns that key back into the
// bundled, optimized asset Vite already ships for this storefront.
const productImages: Record<string, string> = {
  "monolith-stool": stool,
  "fracture-vase": vase,
  "axis-task-light": lamp,
  "atlas-throw": throwImg,
  "field-notebook": notebook,
  "arch-bookend": bookend,
  "amber-carafe": carafe,
  "meridian-clock": clock,
  "grain-board": board,
  "travertine-holder": incense,
  "hearth-slippers": slippers,
  "verde-kettle": kettle,
};

const fallbackImage = stool;

export function getProductImage(imageKey: string): string {
  return productImages[imageKey] ?? fallbackImage;
}

export const categories = [
  "All",
  "Furniture",
  "Ceramics",
  "Lighting",
  "Textiles",
  "Stationery",
  "Kitchen",
  "Apparel",
  "Objects",
] as const;
