export interface Spec {
  label: string;
  value: string;
}

export interface Review {
  _id?: string;
  user?: string;
  author: string;
  rating: number;
  title: string;
  body: string;
  date: string;
}

export type Category =
  | "Furniture"
  | "Ceramics"
  | "Lighting"
  | "Textiles"
  | "Stationery"
  | "Objects"
  | "Kitchen"
  | "Apparel";

export interface Product {
  _id: string;
  slug: string;
  code: string;
  name: string;
  material: string;
  category: Category;
  price: number;
  discount?: number;
  finalPrice: number;
  avgRating: number;
  imageKey: string;
  tagline: string;
  description: string;
  specs: Spec[];
  reviews: Review[];
  stock: number;
  createdAt?: string;
  updatedAt?: string;
}

export type Role = "buyer" | "seller";

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  studioName?: string;
}

export interface OrderItem {
  product: string;
  slug: string;
  name: string;
  price: number;
  quantity: number;
  imageKey?: string;
}

export type OrderStatus = "Processing" | "Shipped" | "Delivered" | "Cancelled";

export interface Order {
  _id: string;
  orderNumber: string;
  user: string | { _id: string; name: string; email: string };
  items: OrderItem[];
  subtotal: number;
  shipping: number;
  total: number;
  status: OrderStatus;
  createdAt: string;
}

export interface DashboardSummary {
  revenue30d: number;
  activeOrders: number;
  ordersNeedingAction: number;
  repeatCustomerRate: number;
  totalOrders: number;
  salesBars: Array<{ label: string; total: number; heightPct: number }>;
  topProducts: Array<{ name: string; units: number; revenue: number }>;
}

export interface InventoryRow {
  slug: string;
  code: string;
  name: string;
  stock: number;
  low: boolean;
}
