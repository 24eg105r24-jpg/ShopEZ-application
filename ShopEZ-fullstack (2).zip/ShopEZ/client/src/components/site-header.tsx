import { Link, useRouterState, useRouter } from "@tanstack/react-router";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/lib/auth";

const nav = [
  { to: "/catalog", label: "Catalog" },
  { to: "/dashboard", label: "Seller Portal" },
] as const;

export function SiteHeader() {
  const { count } = useCart();
  const { user, logout } = useAuth();
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav className="sticky top-0 z-50 flex items-center justify-between border-b border-border bg-background/85 px-6 py-4 backdrop-blur-md">
      <Link to="/" className="text-2xl font-extrabold uppercase tracking-tighter">
        Shop<span className="text-primary">EZ</span>
      </Link>
      <div className="hidden gap-8 font-mono text-xs uppercase tracking-widest md:flex">
        {nav.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className={
              pathname.startsWith(item.to)
                ? "text-primary"
                : "transition-colors hover:text-primary"
            }
          >
            {item.label}
          </Link>
        ))}
      </div>
      <div className="flex items-center gap-6 font-mono text-xs uppercase tracking-widest">
        {user ? (
          <button
            onClick={() => {
              logout();
              router.navigate({ to: "/" });
            }}
            className="transition-colors hover:text-primary"
            title={user.email}
          >
            {user.name.split(" ")[0]} · Sign out
          </button>
        ) : (
          <Link to="/login" className="transition-colors hover:text-primary">
            Sign in
          </Link>
        )}
        <Link to="/cart" className="transition-colors hover:text-primary">
          Cart ({String(count).padStart(2, "0")})
        </Link>
      </div>
    </nav>
  );
}
