export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-muted/30 px-6 py-12">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 md:flex-row">
        <div className="font-mono text-xs uppercase tracking-widest opacity-60">
          © 2026 ShopEZ Modular Ltd.
        </div>
        <div className="flex gap-8 font-mono text-[10px] uppercase tracking-widest">
          <a href="#" className="transition-colors hover:text-primary">Privacy</a>
          <a href="#" className="transition-colors hover:text-primary">Shipping</a>
          <a href="#" className="transition-colors hover:text-primary">Journal</a>
          <a href="#" className="transition-colors hover:text-primary">Instagram</a>
        </div>
      </div>
    </footer>
  );
}
