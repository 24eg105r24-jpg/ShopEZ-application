import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { DashboardSummary, InventoryRow } from "@/lib/types";

export function useDashboardSummary(enabled: boolean) {
  return useQuery({
    queryKey: ["dashboard", "summary"],
    queryFn: () => api.get<DashboardSummary>("/dashboard/summary"),
    enabled,
  });
}

export function useInventory(enabled: boolean) {
  return useQuery({
    queryKey: ["dashboard", "inventory"],
    queryFn: () => api.get<InventoryRow[]>("/dashboard/inventory"),
    enabled,
  });
}
