import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { Product, Review } from "@/lib/types";

export function useProducts(params: { category?: string; sort?: string; search?: string } = {}) {
  const query = new URLSearchParams();
  if (params.category && params.category !== "All") query.set("category", params.category);
  if (params.sort) query.set("sort", params.sort);
  if (params.search) query.set("search", params.search);
  const qs = query.toString();

  return useQuery({
    queryKey: ["products", params],
    queryFn: () => api.get<Product[]>(`/products${qs ? `?${qs}` : ""}`),
  });
}

export function useProduct(slug: string) {
  return useQuery({
    queryKey: ["product", slug],
    queryFn: () => api.get<Product>(`/products/${slug}`),
    enabled: Boolean(slug),
  });
}

export function useAddReview(slug: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (review: Pick<Review, "rating" | "title" | "body">) =>
      api.post<Product>(`/products/${slug}/reviews`, review),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["product", slug] });
    },
  });
}
