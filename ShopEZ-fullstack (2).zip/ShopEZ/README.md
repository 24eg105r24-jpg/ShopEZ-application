# ShopEZ

A full-stack e-commerce storefront: curated product catalog, reviews,
discounts, cart & secure checkout, and a seller dashboard with real
order/inventory analytics.

```
ShopEZ/
├── client/   React 19 + TanStack Start (SSR) + Tailwind — the storefront UI
└── server/   Node.js + Express + MongoDB + JWT — the REST API
```

## Stack
- **Frontend:** React, TypeScript, TanStack Router/Start, TanStack Query, Tailwind CSS, Bootstrap-style utility patterns via shadcn/ui + Radix
- **Backend:** Node.js, Express.js, MongoDB (Mongoose)
- **Auth:** JSON Web Tokens (JWT), bcrypt password hashing
- **Async:** async/await throughout both client (fetch + React Query) and server (Express + Mongoose)

## Quick start

You need Node.js 18+ and a MongoDB instance (local `mongod`, Docker, or a
free MongoDB Atlas cluster).

### 1. Backend

```bash
cd server
npm install
cp .env.example .env      # set MONGO_URI and JWT_SECRET
npm run seed               # loads the 12-piece catalog + demo accounts
npm run dev                 # http://localhost:5000
```

### 2. Frontend

```bash
cd client
npm install
cp .env.example .env      # VITE_API_URL=http://localhost:5000/api
npm run dev                 # http://localhost:3000 (or the port Vite prints)
```

Open the printed local URL, browse the catalog, sign up, add items to your
cart, and check out — orders are created for real in MongoDB.

### Demo accounts (created by `npm run seed`)

| Role   | Email             | Password    |
|--------|-------------------|-------------|
| Seller | seller@shopez.com | password123 |
| Buyer  | buyer@shopez.com  | password123 |

Sign in as the seller and visit **Seller Portal** in the nav to see live
revenue, top products, order management, and inventory — all pulled from
MongoDB through the Express API.

## What's wired up

- **Catalog & product pages** — fetched live from `GET /api/products` and
  `GET /api/products/:slug`, including category filters, sorting, and
  discount pricing computed server-side.
- **Reviews** — signed-in users can post a review; it's saved to MongoDB and
  the average rating updates immediately.
- **Cart** — still kept client-side (localStorage) for a snappy guest
  experience; checkout requires sign-in and posts to `POST /api/orders`,
  which validates stock, decrements inventory, and creates a real order.
- **Auth** — JWT issued on register/login, stored client-side, sent as
  `Authorization: Bearer <token>` on every protected request.
- **Seller dashboard** — revenue, active orders, repeat-customer rate,
  12-month sales chart, top products, order list with status updates, and
  live inventory — all computed from real `Order`/`Product` documents in
  `GET /api/dashboard/summary` and `GET /api/dashboard/inventory`.

See `server/README.md` for the full API reference.

## Notes on images

The backend doesn't store binary images — each product has an `imageKey`
that the frontend maps back to its bundled photo (`client/src/lib/productImages.ts`).
This keeps the original hand-picked photography without needing a file
upload/storage pipeline. If you add new products via the API, either reuse
an existing `imageKey` or add a new bundled asset + map entry.

## Verified wiring

Before packaging, the client and server were run together against each
other live (no MongoDB attached, since that step needs your own database):

- `GET /api/health` → `{"status":"ok", ...}` — Express boots and serves
  requests immediately.
- The React homepage, rendered via SSR, correctly called
  `GET /api/products` and rendered the loading state while the (unattached)
  database call was pending, and the header correctly reflected live
  auth/cart state (`Sign in`, `Cart (00)`).
- `GET /api/products` returned a clean Mongoose "query timed out" error
  rather than crashing — proving the Express → Mongoose → MongoDB path is
  correctly wired end-to-end; it just needs a real `MONGO_URI`.

The only remaining step is pointing `server/.env`'s `MONGO_URI` at a real
MongoDB — either a local `mongod`, or a free
[MongoDB Atlas](https://www.mongodb.com/cloud/atlas/register) cluster
(takes about two minutes to create and gives you a ready-to-use connection
string). Once that's set and `npm run seed` is run, everything above
returns real data instead of timing out.
